# Parte 2

- [x] Tema 1
- [x] Tema 2
- [ ] Tema 3 (?!)
- [x] Tema 4
- [x] Tema 5
- [x] Tema 6 (vedi 7)
- [x] Tema 7
- [ ] Tema 8 (Coda a priorità skipped)
- [ ] Tema 9 (GEO?!)
- [ ] Tema 10 (Dispatcher) no main
- [x] Tema 11 ripasso container
- [ ] Tema 12
- [x] Tema 13
- [ ] Tema 14 su Drive 2016-06-25
