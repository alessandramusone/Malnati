# OS161

BEST DEBUG EVAH
```
if (l(lock)){
    print
}

KASSERT(!l(lock));
```

